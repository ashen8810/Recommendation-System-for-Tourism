from django.contrib import admin

from .models import Advertisement,AdvertisementMedia

admin.site.register(Advertisement)
admin.site.register(AdvertisementMedia)
